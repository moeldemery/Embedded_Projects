# MQTT Temperature Logger via ESP8266
Refer to: http://www.atakansarioglu.com/how-to-iot-mqtt-on-stm32-cortex-m-esp8266-wifi-temperature-freertos/

## Clone
git clone https://github.com/atakansarioglu/mqtt_temperature_logger_esp8266.git

cd mqtt_temperature_logger_esp8266

git submodule update --init --recursive

## Compile
Refer to: http://www.atakansarioglu.com/embedded-mcu-software-development-eclipse-setup-debug/
